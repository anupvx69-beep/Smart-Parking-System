/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { User, ParkingSlot, Reservation, Vehicle } from './src/types';

const DB_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DB_DIR, 'parking_db.json');

interface Schema {
  users: User[];
  slots: ParkingSlot[];
  reservations: Reservation[];
  vehicles: Vehicle[];
}

export class JsonDatabase {
  private data: Schema = {
    users: [],
    slots: [],
    reservations: [],
    vehicles: []
  };

  constructor() {
    this.init();
  }

  private init() {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }

    if (fs.existsSync(DB_FILE)) {
      try {
        const fileContent = fs.readFileSync(DB_FILE, 'utf-8');
        this.data = JSON.parse(fileContent);
        // Ensure standard structure is present
        this.data.users = this.data.users || [];
        this.data.slots = this.data.slots || [];
        this.data.reservations = this.data.reservations || [];
        this.data.vehicles = this.data.vehicles || [];
      } catch (err) {
        console.error('Error reading database file, resetting to empty', err);
        this.bootstrap();
      }
    } else {
      this.bootstrap();
    }
  }

  private save() {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Error writing to database file', err);
    }
  }

  private bootstrap() {
    console.log('Bootstrapping database with default slots and users...');
    this.data = {
      users: [],
      slots: [],
      reservations: [],
      vehicles: []
    };

    // Pre-create default accounts
    const adminPasswordHash = bcrypt.hashSync('admin123', 10);
    const userPasswordHash = bcrypt.hashSync('user123', 10);

    this.data.users.push(
      {
        _id: 'u_admin',
        name: 'Super Admin',
        email: 'admin@parking.com',
        role: 'admin',
        password: adminPasswordHash
      },
      {
        _id: 'u_user',
        name: 'Regular User',
        email: 'user@parking.com',
        role: 'user',
        password: userPasswordHash
      }
    );

    // Bootstrap available slots (Grid: A1-A10, B1-B10, C1-C10)
    const zones = ['A', 'B', 'C'];
    for (const zone of zones) {
      for (let i = 1; i <= 10; i++) {
        const slotId = `${zone}${i}`;
        this.data.slots.push({
          _id: `slot_${slotId}`,
          slotId,
          status: 'available',
          vehicleNumber: '',
          ownerName: '',
          entryTime: null,
          lastSensorUpdate: new Date().toISOString()
        });
      }
    }

    // Seed some historical vehicle exits for past 7 days to populate analytics
    this.seedHistoricalData();
    this.save();
  }

  private seedHistoricalData() {
    const names = ['John Doe', 'Alice Smith', 'Robert Johnson', 'Emily Davis', 'Michael Brown', 'Sophia Wilson', 'David Taylor', 'Olivia Thomas'];
    const vehiclePrefs = ['CA-1234', 'NY-9876', 'TX-5512', 'WA-8801', 'OR-4321', 'FL-6712', 'NV-3490', 'AZ-1122'];
    
    const now = new Date();
    
    // Create 45 historical records spread over the past 7 days
    for (let i = 0; i < 45; i++) {
      const daysAgo = Math.floor(i / 6); // spread over ~7 days
      const hourOffset = (i % 6) * 3 + Math.floor(Math.random() * 2); // different hours of target day
      
      const entryTime = new Date(now);
      entryTime.setDate(now.getDate() - daysAgo);
      entryTime.setHours(8 + hourOffset, Math.floor(Math.random() * 60), 0, 0);
      
      const durationHours = Math.floor(Math.random() * 4) + 1; // 1-5 hours
      const exitTime = new Date(entryTime);
      exitTime.setHours(entryTime.getHours() + durationHours);

      const fee = durationHours * 5; // $5 per hour

      this.data.vehicles.push({
        _id: `v_hist_${i}`,
        vehicleNumber: vehiclePrefs[i % vehiclePrefs.length] + `-${daysAgo}`,
        ownerName: names[i % names.length],
        entryTime: entryTime.toISOString(),
        exitTime: exitTime.toISOString(),
        duration: durationHours * 60,
        fee,
        status: 'exited'
      });
    }

    // Add 4 currently parked vehicles (which also occupies their respective slots)
    const activeParkings = [
      { slotId: 'A1', vehicleNumber: 'CA-9988', ownerName: 'Geralt of Rivia' },
      { slotId: 'A3', vehicleNumber: 'TX-4400', ownerName: 'Bruce Wayne' },
      { slotId: 'B2', vehicleNumber: 'WA-7312', ownerName: 'Diana Prince' },
      { slotId: 'C5', vehicleNumber: 'NY-3388', ownerName: 'Tony Stark' },
    ];

    for (let i = 0; i < activeParkings.length; i++) {
      const p = activeParkings[i];
      const entryTime = new Date(now);
      entryTime.setHours(now.getHours() - (i + 1)); // 1 to 4 hours ago

      // Mark the slot occupied in main slot storage
      const slot = this.data.slots.find(s => s.slotId === p.slotId);
      if (slot) {
        slot.status = 'occupied';
        slot.vehicleNumber = p.vehicleNumber;
        slot.ownerName = p.ownerName;
        slot.entryTime = entryTime.toISOString();
        slot.lastSensorUpdate = new Date().toISOString();
      }

      // Add to vehicles list
      this.data.vehicles.push({
        _id: `v_active_${i}`,
        vehicleNumber: p.vehicleNumber,
        ownerName: p.ownerName,
        entryTime: entryTime.toISOString(),
        status: 'parked'
      });
    }

    // Add 2 active reservations too for A5 and B6
    const resList = [
      { slotId: 'A5', user: 'u_user', name: 'Regular User' },
      { slotId: 'B6', user: 'u_user', name: 'Regular User' }
    ];

    for (let i = 0; i < resList.length; i++) {
      const r = resList[i];
      const rDate = new Date();
      rDate.setHours(rDate.getHours() + 1); // reservation for 1 hour from now

      const slot = this.data.slots.find(s => s.slotId === r.slotId);
      if (slot) {
        slot.status = 'reserved';
        slot.lastSensorUpdate = new Date().toISOString();
      }

      this.data.reservations.push({
        _id: `res_active_${i}`,
        userId: r.user,
        userName: r.name,
        slotId: r.slotId,
        reservationDate: rDate.toISOString(),
        status: 'active'
      });
    }
  }

  // --- USERS ---
  getUsers(): User[] {
    return this.data.users;
  }

  getUserByEmail(email: string): User | undefined {
    return this.data.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  createUser(user: Omit<User, '_id'>): User {
    const newUser: User = {
      ...user,
      _id: 'u_' + Math.random().toString(36).substr(2, 9)
    };
    this.data.users.push(newUser);
    this.save();
    return newUser;
  }

  // --- PARKING SLOTS ---
  getSlots(): ParkingSlot[] {
    return this.data.slots;
  }

  getSlotById(slotId: string): ParkingSlot | undefined {
    return this.data.slots.find(s => s.slotId.toUpperCase() === slotId.toUpperCase());
  }

  updateSlot(slotId: string, updates: Partial<ParkingSlot>): ParkingSlot | null {
    const slot = this.getSlotById(slotId);
    if (!slot) return null;
    
    Object.assign(slot, updates);
    slot.lastSensorUpdate = new Date().toISOString();
    this.save();
    return slot;
  }

  // --- VEHICLES ---
  getVehicles(): Vehicle[] {
    return this.data.vehicles;
  }

  getActiveVehicleByNumber(vehicleNumber: string): Vehicle | undefined {
    return this.data.vehicles.find(v => v.vehicleNumber.toUpperCase() === vehicleNumber.toUpperCase() && v.status === 'parked');
  }

  recordVehicleEntry(vehicleNumber: string, ownerName: string): Vehicle {
    const newVehicle: Vehicle = {
      _id: 'v_e_' + Math.random().toString(36).substr(2, 9),
      vehicleNumber: vehicleNumber.toUpperCase(),
      ownerName,
      entryTime: new Date().toISOString(),
      status: 'parked'
    };
    this.data.vehicles.push(newVehicle);
    this.save();
    return newVehicle;
  }

  recordVehicleExit(vehicleNumber: string, totalHours: number, fee: number): Vehicle | null {
    const vehicle = this.getActiveVehicleByNumber(vehicleNumber);
    if (!vehicle) return null;

    vehicle.exitTime = new Date().toISOString();
    vehicle.duration = totalHours * 60; // in minutes
    vehicle.fee = fee;
    vehicle.status = 'exited';
    this.save();
    return vehicle;
  }

  // --- RESERVATIONS ---
  getReservations(): Reservation[] {
    return this.data.reservations;
  }

  createReservation(userId: string, userName: string, slotId: string, reservationDate: string): Reservation {
    const newRes: Reservation = {
      _id: 'res_' + Math.random().toString(36).substr(2, 9),
      userId,
      userName,
      slotId,
      reservationDate,
      status: 'active'
    };
    this.data.reservations.push(newRes);
    
    // Set status of slot to reserved
    this.updateSlot(slotId, { status: 'reserved' });
    
    this.save();
    return newRes;
  }

  cancelReservation(reservationId: string): Reservation | null {
    const res = this.data.reservations.find(r => r._id === reservationId && r.status === 'active');
    if (!res) return null;

    res.status = 'cancelled';
    
    // Set slot status back to available if it was reserved
    const slot = this.getSlotById(res.slotId);
    if (slot && slot.status === 'reserved') {
      slot.status = 'available';
    }

    this.save();
    return res;
  }

  fulfillReservation(slotId: string, userId: string): Reservation | null {
    const res = this.data.reservations.find(r => r.slotId === slotId && r.userId === userId && r.status === 'active');
    if (!res) return null;

    res.status = 'fulfilled';
    this.save();
    return res;
  }
}

export const db = new JsonDatabase();
