/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Vehicle } from '../types';
import { 
  FileSpreadsheet, 
  Printer, 
  Download, 
  Calendar, 
  Wallet, 
  Clock, 
  LineChart,
  Grid
} from 'lucide-react';

export const ReportsSection: React.FC = () => {
  const { searchHistory, slots } = useApp();
  const [reportType, setReportType] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [reportData, setReportData] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(false);

  // Fetch report data based on selection
  const fetchReport = async () => {
    setLoading(true);
    const allLogs = await searchHistory(''); // Fetch complete history logs
    const now = new Date();
    
    let filtered: Vehicle[] = [];

    if (reportType === 'daily') {
      // Past 24 hours
      const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      filtered = allLogs.filter(v => new Date(v.entryTime) >= yesterday);
    } else if (reportType === 'weekly') {
      // Past 7 days
      const lastWeek = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      filtered = allLogs.filter(v => new Date(v.entryTime) >= lastWeek);
    } else if (reportType === 'monthly') {
      // Past 30 days
      const lastMonth = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      filtered = allLogs.filter(v => new Date(v.entryTime) >= lastMonth);
    }

    setReportData(filtered);
    setLoading(false);
  };

  useEffect(() => {
    fetchReport();
  }, [reportType, slots]);

  // Calculations
  const totalVehicles = reportData.length;
  const exitedVehicles = reportData.filter(v => v.status === 'exited');
  const totalRevenue = exitedVehicles.reduce((sum, v) => sum + (v.fee || 0), 0);
  
  const totalDurationMinutes = exitedVehicles.reduce((sum, v) => sum + (v.duration || 0), 0);
  const averageDurationHours = totalVehicles > 0 && exitedVehicles.length > 0
    ? Math.round((totalDurationMinutes / exitedVehicles.length) / 60 * 10) / 10
    : 0;

  // Trigger Native Print Window styled for Printable PDF Layouts
  const handlePdfPrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 print:hidden">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">Financial & Traffic Reports</h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm">Compile operational statistics, export archives, or trigger printed receipts.</p>
        </div>

        {/* Action downloads */}
        <div className="flex items-center gap-2.5">
          {/* CSV Download Link */}
          <a
            id="csv-export-btn"
            href="/api/reports/csv"
            download
            className="px-4.5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/10 flex items-center gap-2 transition-all cursor-pointer"
          >
            <Download className="h-4 w-4" />
            <span>Download CSV report</span>
          </a>

          {/* Styled Print Button */}
          <button
            id="pdf-print-btn"
            onClick={handlePdfPrint}
            className="px-4.5 py-2.5 bg-slate-800 hover:bg-slate-900 border dark:border-slate-800 dark:bg-slate-100 dark:hover:bg-slate-50 text-white dark:text-slate-900 rounded-xl text-xs font-bold flex items-center gap-2 shadow-sm transition-all cursor-pointer"
          >
            <Printer className="h-4 w-4" />
            <span>Export Printable PDF</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs (Print hid) */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-1 print:hidden">
        {(['daily', 'weekly', 'monthly'] as const).map((type) => (
          <button
            key={type}
            onClick={() => setReportType(type)}
            className={`px-4.5 py-2 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
              reportType === type 
                ? 'bg-blue-600 text-white shadow-md shadow-blue-500/15' 
                : 'text-slate-500 dark:text-slate-400 hover:bg-slate-200/50 dark:hover:bg-slate-900/50'
            }`}
          >
            {type} Report
          </button>
        ))}
      </div>

      {/* Report Summary Cards (Print layout optimized) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm text-slate-800 dark:text-white">
          <div className="flex items-center gap-2 text-slate-400 mb-2">
            <LineChart className="h-4.5 w-4.5 text-blue-500" />
            <span className="text-xs font-semibold uppercase tracking-wide font-mono">Processed Vehicles</span>
          </div>
          <div className="text-2xl font-black font-mono">{totalVehicles}</div>
          <p className="text-[10px] text-slate-400 mt-1 italic">Total entries recorded inside target timeframe</p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm text-slate-800 dark:text-white">
          <div className="flex items-center gap-2 text-slate-400 mb-2">
            <Wallet className="h-4.5 w-4.5 text-emerald-500" />
            <span className="text-xs font-semibold uppercase tracking-wide font-mono">Accumulated Levy</span>
          </div>
          <div className="text-2xl font-black font-mono">$ {totalRevenue}.00</div>
          <p className="text-[10px] text-slate-400 mt-1 italic">Earned processing charges</p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm text-slate-800 dark:text-white">
          <div className="flex items-center gap-2 text-slate-400 mb-2">
            <Clock className="h-4.5 w-4.5 text-amber-500" />
            <span className="text-xs font-semibold uppercase tracking-wide font-mono">Avg Session Duration</span>
          </div>
          <div className="text-2xl font-black font-mono">{averageDurationHours} hr(s)</div>
          <p className="text-[10px] text-slate-400 mt-1 italic">Mean occupancy duration per vehicle</p>
        </div>
      </div>

      {/* Main reporting table list */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl shadow-sm space-y-4">
        <div className="flex justify-between items-center mb-1">
          <div>
            <h3 className="text-md font-bold text-slate-900 dark:text-white capitalize">{reportType} Traffic & Auditing Ledger</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Itemized transaction logs generated at: {new Date().toLocaleDateString()}</p>
          </div>
          <span className="hidden print:inline text-xs font-mono border dark:border-slate-800 px-3 py-1 rounded bg-slate-55 dark:bg-slate-950 text-slate-500">
            OFFICIAL SECURITY AUDIT
          </span>
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-150 dark:border-slate-800/80">
          <table className="w-full text-left text-xs divide-y divide-slate-100 dark:divide-slate-800/80">
            <thead className="bg-slate-50 dark:bg-slate-950 text-slate-500 dark:text-slate-400 font-bold uppercase font-mono text-[10px] tracking-wide">
              <tr>
                <th className="p-4">Owner Name</th>
                <th className="p-4">License Plate</th>
                <th className="p-4">Arrival Entry Time</th>
                <th className="p-4">Departure Exit Time</th>
                <th className="p-4 text-center">Session Status</th>
                <th className="p-4 text-right">Fee Charge ($)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium text-slate-700 dark:text-slate-350">
              {loading ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400">
                    Compiling report sheets...
                  </td>
                </tr>
              ) : reportData.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400 dark:text-slate-600">
                    No active transaction records identified within selected timeframe.
                  </td>
                </tr>
              ) : (
                reportData.map((log) => (
                  <tr key={log._id} className="hover:bg-slate-50/50 dark:hover:bg-slate-900/10">
                    <td className="p-4 font-semibold text-slate-900 dark:text-white">{log.ownerName}</td>
                    <td className="p-4 font-mono font-bold text-blue-600 dark:text-blue-400">{log.vehicleNumber}</td>
                    <td className="p-4 font-mono text-slate-500 dark:text-slate-400 text-[11px]">
                      {new Date(log.entryTime).toLocaleDateString()} {new Date(log.entryTime).toLocaleTimeString()}
                    </td>
                    <td className="p-4 font-mono text-slate-500 dark:text-slate-400 text-[11px]">
                      {log.exitTime ? (
                        `${new Date(log.exitTime).toLocaleDateString()} ${new Date(log.exitTime).toLocaleTimeString()}`
                      ) : (
                        <span className="italic text-rose-500">Currently Parked</span>
                      )}
                    </td>
                    <td className="p-4 text-center text-[10px]">
                      <span className={`inline-block px-2.5 py-0.5 font-bold font-mono tracking-wide rounded-md uppercase ${
                        log.status === 'parked' ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400' : 'bg-slate-100 dark:bg-slate-800'
                      }`}>
                        {log.status}
                      </span>
                    </td>
                    <td className="p-4 text-right font-mono font-bold text-slate-900 dark:text-white">
                      {log.fee ? `$ ${log.fee}` : '$ 0'}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
export default ReportsSection;
