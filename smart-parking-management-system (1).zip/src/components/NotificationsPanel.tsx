/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Bell, CheckCircle2, AlertCircle, Info, X, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const NotificationsPanel: React.FC = () => {
  const { notifications, clearNotification } = useApp();

  // Pick top 4 newest notifications to avoid filling up the page with popups
  const activeNotifications = notifications.slice(0, 4);

  return (
    <div className="fixed top-5 right-5 z-55 w-full max-w-sm space-y-3 pointer-events-none print:hidden">
      <AnimatePresence>
        {activeNotifications.map((notif) => {
          let IconComponent = Info;
          let colorStyle = 'bg-white border-slate-200 text-slate-800 dark:bg-slate-900 dark:border-slate-800 dark:text-slate-100';

          if (notif.type === 'success') {
            IconComponent = CheckCircle2;
            colorStyle = 'bg-emerald-50 border-emerald-200 dark:bg-emerald-950/20 dark:border-emerald-900/60 text-emerald-800 dark:text-emerald-400';
          } else if (notif.type === 'warning') {
            IconComponent = AlertCircle;
            colorStyle = 'bg-amber-50 border-amber-200 dark:bg-amber-950/20 dark:border-amber-900/60 text-amber-850 dark:text-amber-400';
          } else if (notif.type === 'danger') {
            IconComponent = ShieldAlert;
            colorStyle = 'bg-rose-50 border-rose-200 dark:bg-rose-950/20 dark:border-rose-900/60 text-rose-800 dark:text-rose-400';
          }

          return (
            <motion.div
              key={notif.id}
              layout
              initial={{ opacity: 0, x: 80, scale: 0.95 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 50, scale: 0.95 }}
              transition={{ type: 'spring', stiffness: 280, damping: 25 }}
              className={`p-4 border rounded-2xl shadow-lg flex items-start gap-3 pointer-events-auto ${colorStyle}`}
            >
              <div className="mt-0.5 shrink-0">
                <IconComponent className="h-5 w-5" />
              </div>
              <div className="lex-1 min-w-0 pr-4">
                <p className="text-xs font-semibold leading-relaxed">{notif.message}</p>
                <span className="text-[9px] font-mono opacity-60 block mt-1.5 font-medium">
                  {new Date(notif.timestamp).toLocaleTimeString()}
                </span>
              </div>
              <button
                id={`dismiss-notif-${notif.id}`}
                onClick={() => clearNotification(notif.id)}
                className="hover:opacity-100 opacity-60 text-current p-1 ml-auto shrink-0 transition-opacity"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
};
export default NotificationsPanel;
