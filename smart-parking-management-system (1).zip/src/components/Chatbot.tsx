/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, Send, X, Bot, Sparkles, RefreshCw, Zap, Trash2, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../context/AppContext';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

const QUICK_ACTIONS = [
  'Show available slots',
  'What is the hourly fee?',
  'Is slot A1 occupied?',
  'How do I reserve a slot?'
];

export const Chatbot: React.FC = () => {
  const { token } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: 'Hello! I am **SmartParkAI**, your virtual parking manager. I am connected directly to our live **IoT sensor grid**. Ask me about vacant slots, active vehicle logs, or billing rates!'
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen, isLoading]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMessage: Message = { role: 'user', content: textToSend };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    setErrorMsg(null);

    try {
      const response = await fetch('/api/chatbot', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          message: textToSend,
          history: messages
        })
      });

      if (!response.ok) {
        throw new Error('Failed to retrieve response from SmartParkAI');
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      setMessages(prev => [...prev, { role: 'assistant', content: data.reply }]);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Connecting signal failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const clearChat = () => {
    setMessages([
      {
        role: 'assistant',
        content: 'Chat history cleared. I am ready for new queries! Ask me anything about the **SmartPark IoT grid**.'
      }
    ]);
    setErrorMsg(null);
  };

  // Inline formatting helper for minimal markdown bold & bullet rendering
  const renderInlineBold = (text: string) => {
    const parts = text.split(/\*\*([\s\S]+?)\*\*/g);
    return parts.map((part, i) => {
      if (i % 2 === 1) {
        return (
          <strong key={i} className="font-extrabold text-blue-400">
            {part}
          </strong>
        );
      }
      return part;
    });
  };

  const renderFormattedContent = (text: string) => {
    const lines = text.split('\n');
    return lines.map((line, idx) => {
      // Bullets check
      if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
        const content = line.trim().substring(2).trim();
        return (
          <li key={idx} className="ml-4 list-disc mt-1 text-slate-300 text-xs pl-0.5 leading-relaxed">
            {renderInlineBold(content)}
          </li>
        );
      }
      return (
        <p key={idx} className={`text-xs leading-relaxed mt-1.5 first:mt-0 text-slate-200`}>
          {renderInlineBold(line)}
        </p>
      );
    });
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 font-sans print:hidden flex flex-col items-end">
      {/* Expandable Chat window layout container */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 35, scale: 0.92 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 25, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 220 }}
            className="w-80 sm:w-96 h-[500px] bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden mb-4 mr-0.5"
            id="chatbot-window-panel"
          >
            {/* Header section with blue custom glow details */}
            <div className="bg-slate-950 p-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="relative bg-blue-500/10 p-2 rounded-xl border border-blue-500/20 text-blue-400">
                  <Bot className="h-5 w-5" />
                  <span className="absolute bottom-0 right-0 h-2 w-2 rounded-full bg-emerald-500 ring-2 ring-slate-950"></span>
                </div>
                <div>
                  <h3 className="text-sm font-extrabold tracking-tight text-white flex items-center gap-1.5">
                    <span>SmartParkAI</span>
                    <Sparkles className="h-3 w-3 text-blue-400 animate-pulse" />
                  </h3>
                  <div className="flex items-center gap-1.5 text-[9px] font-semibold text-blue-400 uppercase tracking-widest font-mono select-none">
                    <span className="relative flex h-1.5 w-1.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-blue-500"></span>
                    </span>
                    <span>IoT Gateway Connected</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={clearChat}
                  className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800/80 transition-colors cursor-pointer"
                  title="Clear Chat Logs"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1.5 rounded-lg text-slate-500 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer"
                  title="Minimize Chat"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Chat list viewport */}
            <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-900/60 custom-scrollbar">
              {messages.map((msg, index) => {
                const isAi = msg.role === 'assistant';
                return (
                  <div
                    key={index}
                    className={`flex items-start gap-2.5 ${isAi ? '' : 'flex-row-reverse'}`}
                  >
                    <div
                      className={`p-2 rounded-xl text-xs shrink-0 ${
                        isAi 
                          ? 'bg-blue-600/10 border border-blue-500/20 text-blue-400' 
                          : 'bg-slate-800 border border-slate-700 text-slate-300'
                      }`}
                    >
                      <Bot className="h-3.5 w-3.5" />
                    </div>
                    <div className="flex flex-col max-w-[78%]">
                      <div
                        className={`p-3 rounded-2xl text-xs ${
                          isAi
                            ? 'bg-slate-950 border border-slate-800 text-slate-100 rounded-tl-none shadow-md'
                            : 'bg-blue-600 text-white rounded-tr-none shadow-lg shadow-blue-600/10'
                        }`}
                      >
                        {isAi ? renderFormattedContent(msg.content) : msg.content}
                      </div>
                      <span className="text-[9px] text-slate-500 mt-1 px-1 font-medium italic">
                        {isAi ? 'SmartParkAI' : 'Client User'}
                      </span>
                    </div>
                  </div>
                );
              })}

              {/* Response processing state bar */}
              {isLoading && (
                <div className="flex items-start gap-2.5">
                  <div className="p-2 rounded-xl text-xs shrink-0 bg-blue-600/10 border border-blue-500/20 text-blue-400 animate-pulse">
                    <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                  </div>
                  <div className="p-3 bg-slate-955 border border-slate-800 text-slate-100 rounded-2xl rounded-tl-none flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              )}

              {errorMsg && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded-2xl text-xs flex items-start gap-2">
                  <span className="mt-0.5 shrink-0 text-rose-500 font-extrabold uppercase font-mono text-[9px] px-1 bg-rose-500/10 rounded border border-rose-500/20">ERR</span>
                  <div className="flex-1 leading-normal text-rose-300">
                    {errorMsg}
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Quick Actions drawer footer */}
            <div className="px-4 py-2 bg-slate-950/85 border-t border-slate-850 flex items-center gap-1.5 overflow-x-auto whitespace-nowrap scrollbar-none py-2 shrink-0 select-none">
              {QUICK_ACTIONS.map((action, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendMessage(action)}
                  disabled={isLoading}
                  className="px-3 py-1.5 bg-slate-900 border border-slate-800 hover:border-blue-500/30 text-slate-400 hover:text-white text-[10px] font-semibold rounded-full flex items-center gap-1 cursor-pointer transition-all disabled:opacity-50"
                >
                  <span>{action}</span>
                  <ArrowRight className="h-2.5 w-2.5 opacity-60" />
                </button>
              ))}
            </div>

            {/* Message input area */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage(input);
              }}
              className="p-3 bg-slate-950 border-t border-slate-850 flex items-center gap-2"
            >
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                disabled={isLoading}
                placeholder="Ask SmartParkAI anything..."
                className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-xs font-semibold text-white placeholder-slate-550 focus:outline-none focus:ring-1 focus:ring-blue-500/50 focus:border-blue-500/50 disabled:opacity-60"
              />
              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                className="p-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-800 disabled:opacity-40 text-white rounded-xl transition-all cursor-pointer flex items-center justify-center shrink-0"
              >
                <Send className="h-3.5 w-3.5" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Sparkly Chat Launcher Badge */}
      <motion.button
        whileHover={{ scale: 1.05, y: -2 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="h-14 w-14 bg-gradient-to-tr from-blue-600 to-blue-500 text-white rounded-full shadow-lg shadow-blue-600/20 border border-blue-400/20 flex items-center justify-center cursor-pointer relative"
        id="chatbot-launcher-trigger"
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div
              key="close"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
              transition={{ duration: 0.15 }}
            >
              <X className="h-6 w-6" />
            </motion.div>
          ) : (
            <motion.div
              key="chat"
              initial={{ rotate: 90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -90, opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="relative flex items-center justify-center"
            >
              <MessageSquare className="h-6 w-6" />
              <span className="absolute -top-1 -right-1 h-3.5 w-3.5 flex items-center justify-center bg-emerald-500 text-[8px] font-black rounded-full ring-2 ring-slate-900 z-10 animate-bounce">
                AI
              </span>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>
    </div>
  );
};
