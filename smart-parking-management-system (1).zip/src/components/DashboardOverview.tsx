/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  AreaChart, 
  Area,
  LineChart,
  Line
} from 'recharts';
import { 
  Users, 
  Trophy, 
  Banknote, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  TrendingUp,
  Workflow,
  Car,
  Play,
  Pause,
  Zap
} from 'lucide-react';
import { motion } from 'motion/react';

export const DashboardOverview: React.FC = () => {
  const { stats, analyticsData, theme } = useApp();

  const [simEnabled, setSimEnabled] = React.useState<boolean>(true);
  const [simLoading, setSimLoading] = React.useState<boolean>(false);

  React.useEffect(() => {
    fetch('/api/simulation/status')
      .then(res => res.json())
      .then(data => setSimEnabled(data.enabled))
      .catch(err => console.error('Failed to get simulation status', err));
  }, []);

  const handleToggleSim = async () => {
    try {
      setSimLoading(true);
      const res = await fetch('/api/simulation/toggle', { method: 'POST' });
      const data = await res.json();
      setSimEnabled(data.enabled);
    } catch (err) {
      console.error(err);
    } finally {
      setSimLoading(false);
    }
  };

  const handleForceTick = async () => {
    try {
      setSimLoading(true);
      await fetch('/api/simulation/tick', { method: 'POST' });
    } catch (err) {
      console.error(err);
    } finally {
      setSimLoading(false);
    }
  };

  const isDark = theme === 'dark';
  const gridColor = isDark ? '#1e293b' : '#e2e8f0';
  const textColor = isDark ? '#94a3b8' : '#64748b';

  // Stats Card visual mapping
  const statCards = [
    {
      id: 'stat-total-slots',
      title: 'Total slots',
      value: stats.totalSlots,
      icon: Trophy,
      color: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20',
      valueColor: 'text-slate-800 dark:text-slate-100',
      desc: 'Overall grid size'
    },
    {
      id: 'stat-available-slots',
      title: 'Available now',
      value: stats.availableSlots,
      icon: CheckCircle2,
      color: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20',
      valueColor: 'text-emerald-600 dark:text-emerald-400',
      desc: 'Ready for booking'
    },
    {
      id: 'stat-occupied-slots',
      title: 'Occupied slots',
      value: stats.occupiedSlots,
      icon: Car,
      color: 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20',
      valueColor: 'text-rose-600 dark:text-rose-400',
      desc: 'Active vehicles'
    },
    {
      id: 'stat-reserved-slots',
      title: 'Reserved slots',
      value: stats.reservedSlots,
      icon: Clock,
      color: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20',
      valueColor: 'text-amber-600 dark:text-amber-300',
      desc: 'Priority bookings'
    },
    {
      id: 'stat-revenue',
      title: "Today's revenue",
      value: `$${stats.todayRevenue}`,
      icon: Banknote,
      color: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20',
      valueColor: 'text-blue-600 dark:text-blue-400',
      desc: '$5 / hour rate schema'
    },
    {
      id: 'stat-total-parked',
      title: 'Total vehicles parked',
      value: stats.totalVehiclesParked,
      icon: Workflow,
      color: 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border border-slate-500/20',
      valueColor: 'text-slate-800 dark:text-slate-200',
      desc: 'Cumulative logs size'
    }
  ];

  const cardContainerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.05 }
    }
  };

  const cardItemVariants = {
    hidden: { opacity: 0, y: 12 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Page Title & Motivation Text */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">Smart IoT Dashboard</h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm mt-0.5">Real-time stats compiled directly from connected sensor grid nodes.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Live Simulator Panel Controls */}
          <div className="flex items-center gap-2 p-1.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
            <span className="text-[9px] font-black uppercase tracking-wider text-slate-550 dark:text-slate-450 px-1.5 font-mono">SIMULATION:</span>
            <button
              onClick={handleToggleSim}
              disabled={simLoading}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-[10px] font-extrabold font-mono transition-all cursor-pointer ${
                simEnabled
                  ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/20'
                  : 'bg-rose-500/10 border border-rose-500/20 text-rose-600 dark:text-rose-400 hover:bg-rose-500/20'
              }`}
            >
              {simEnabled ? (
                <>
                  <Pause className="h-3 w-3 animate-pulse" />
                  <span>ACTIVE</span>
                </>
              ) : (
                <>
                  <Play className="h-3 w-3" />
                  <span>PAUSED</span>
                </>
              )}
            </button>
            <button
              onClick={handleForceTick}
              disabled={simLoading || !simEnabled}
              className="flex items-center gap-1 px-2.5 py-1 bg-blue-500/15 border border-blue-500/20 hover:bg-blue-550/25 text-blue-500 dark:text-blue-400 rounded-lg text-[10px] font-bold font-mono transition-all cursor-pointer disabled:opacity-40"
              title="Manually force next IoT state change tick"
            >
              <Zap className="h-3 w-3 text-blue-500" />
              <span>FORCE EVENT</span>
            </button>
          </div>

          <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-500/10 border border-blue-500/20 text-blue-600 dark:text-blue-400 text-xs font-semibold rounded-xl font-mono self-start md:self-auto">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
            </span>
            <span>SYSTEM ACTIVE</span>
          </div>
        </div>
      </div>

      {/* Grid: Stats Widgets */}
      <motion.div 
        variants={cardContainerVariants}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-5"
      >
        {statCards.map((card) => {
          const IconComp = card.icon;
          return (
            <motion.div
              key={card.id}
              id={card.id}
              variants={cardItemVariants}
              whileHover={{ y: -4, transition: { duration: 0.15 } }}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-lg dark:shadow-black/25 flex flex-col justify-between"
            >
              <div className="flex items-start justify-between">
                <span className="text-slate-500 dark:text-slate-400 text-xs font-semibold tracking-wide uppercase font-mono">{card.title}</span>
                <div className={`p-2 rounded-xl ${card.color}`}>
                  <IconComp className="h-5 w-5" />
                </div>
              </div>
              <div className="mt-4">
                <span className={`text-2xl sm:text-3xl font-bold tracking-tight font-mono ${card.valueColor || 'text-slate-850 dark:text-slate-100'}`}>{card.value}</span>
                <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 font-medium italic">{card.desc}</p>
              </div>
            </motion.div>
          );
        })}
      </motion.div>

      {/* Grid: Graphs & Analytics */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Graph 1: Daily Turnover */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/80 rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="text-md font-bold text-slate-800 dark:text-slate-200">Daily Parking Events</h3>
              <p className="text-xs text-slate-500 dark:text-slate-500">Vehicles processed inside past 7 days logs</p>
            </div>
            <TrendingUp className="h-5 w-5 text-blue-500" />
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analyticsData.dailyOccupancy} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} vertical={false} />
                <XAxis dataKey="name" tick={{ fill: textColor, fontSize: 11 }} axisLine={false} />
                <YAxis tick={{ fill: textColor, fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: isDark ? '#0f172a' : '#ffffff', 
                    borderColor: isDark ? '#334155' : '#e2e8f0',
                    color: isDark ? '#ffffff' : '#000000',
                    borderRadius: '12px'
                  }}
                  itemStyle={{ fontSize: 12 }}
                  labelStyle={{ fontWeight: 'bold', fontSize: 11 }}
                />
                <Legend iconSize={10} verticalAlign="top" align="right" wrapperStyle={{ fontSize: 11, paddingBottom: 10 }} />
                <Bar dataKey="vehicles" name="Vehicles" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={28} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Graph 2: Monthly Projected Financial Growth */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/80 rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="text-md font-bold text-slate-800 dark:text-slate-200">Monthly Revenue Distribution</h3>
              <p className="text-xs text-slate-500 dark:text-slate-500">Processing fee cashflow records over past 5 months</p>
            </div>
            <Banknote className="h-5 w-5 text-blue-500" />
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={analyticsData.monthlyRevenue} margin={{ top: 5, right: 10, left: -15, bottom: 5 }}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} vertical={false} />
                <XAxis dataKey="name" tick={{ fill: textColor, fontSize: 11 }} axisLine={false} />
                <YAxis tick={{ fill: textColor, fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: isDark ? '#0f172a' : '#ffffff', 
                    borderColor: isDark ? '#334155' : '#e2e8f0',
                    color: isDark ? '#ffffff' : '#000000',
                    borderRadius: '12px'
                  }}
                  itemStyle={{ fontSize: 12 }}
                  labelStyle={{ fontWeight: 'bold', fontSize: 11 }}
                />
                <Area type="monotone" dataKey="revenue" name="Revenue ($)" stroke="#3b82f6" strokeWidth={2.5} fillOpacity={1} fill="url(#colorRev)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Graph 3: Peak Booking Cycles Distribution */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/80 rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="text-md font-bold text-slate-800 dark:text-slate-200">Peak Parking Hours</h3>
              <p className="text-xs text-slate-500 dark:text-slate-500">Hourly density index distribution graph (07:00 - 22:00)</p>
            </div>
            <Clock className="h-5 w-5 text-amber-500" />
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={analyticsData.peakHours} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} vertical={false} />
                <XAxis dataKey="hour" tick={{ fill: textColor, fontSize: 10 }} axisLine={false} />
                <YAxis tick={{ fill: textColor, fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: isDark ? '#0f172a' : '#ffffff', 
                    borderColor: isDark ? '#334155' : '#e2e8f0',
                    color: isDark ? '#ffffff' : '#000000',
                    borderRadius: '12px'
                  }}
                  itemStyle={{ fontSize: 12 }}
                />
                <Line type="basis" dataKey="count" name="Park entry logs" stroke="#f59e0b" strokeWidth={3} dot={false} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Graph 4: Weekly Performance Trends */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/80 rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="text-md font-bold text-slate-800 dark:text-slate-200">Weekly Traffic Sizing</h3>
              <p className="text-xs text-slate-500 dark:text-slate-500">Activity index across past 4 operational weeks</p>
            </div>
            <Users className="h-5 w-5 text-rose-500" />
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analyticsData.weeklyOccupancy} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} vertical={false} />
                <XAxis dataKey="name" tick={{ fill: textColor, fontSize: 11 }} axisLine={false} />
                <YAxis tick={{ fill: textColor, fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: isDark ? '#0f172a' : '#ffffff', 
                    borderColor: isDark ? '#334155' : '#e2e8f0',
                    color: isDark ? '#ffffff' : '#000000',
                    borderRadius: '12px'
                  }}
                  itemStyle={{ fontSize: 12 }}
                />
                <Bar dataKey="count" name="Active sessions" fill="#f43f5e" radius={[4, 4, 0, 0]} barSize={34} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
export default DashboardOverview;
