/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Vehicle } from '../types';
import { 
  Search, 
  History, 
  ArrowRightLeft, 
  Clock, 
  DollarSign, 
  LogOut, 
  LogIn, 
  Tag, 
  Trash2,
  CalendarDays
} from 'lucide-react';
import { motion } from 'motion/react';

export const VehiclesManagement: React.FC = () => {
  const { slots, user, vehicleEntry, vehicleExit, searchHistory } = useApp();
  
  // Search state
  const [searchTerm, setSearchTerm] = useState('');
  const [historyLogs, setHistoryLogs] = useState<Vehicle[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);

  // Form states
  const [entrySlotId, setEntrySlotId] = useState('');
  const [entryPlate, setEntryPlate] = useState('');
  const [entryOwner, setEntryOwner] = useState('');

  const [exitPlate, setExitPlate] = useState('');
  const [activeExitDetail, setActiveExitDetail] = useState<any | null>(null);

  // Available slots for entering
  const vacantSlots = slots.filter(s => s.status === 'available');

  // Load history initially
  const loadHistory = async () => {
    setSearchLoading(true);
    const logs = await searchHistory(searchTerm);
    setHistoryLogs(logs);
    setSearchLoading(false);
  };

  useEffect(() => {
    loadHistory();
  }, [slots]); // Reload history whenever map updates (e.g. exit completes)

  const handleSearchKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      loadHistory();
    }
  };

  const executeEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!entrySlotId || !entryPlate || !entryOwner) return;

    const success = await vehicleEntry(entrySlotId, entryPlate, entryOwner);
    if (success) {
      setEntrySlotId('');
      setEntryPlate('');
      setEntryOwner('');
      loadHistory();
    }
  };

  const executeExit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!exitPlate) return;

    const exitDetail = await vehicleExit(exitPlate);
    if (exitDetail) {
      setActiveExitDetail(exitDetail);
      setExitPlate('');
      loadHistory();
    }
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">Vehicle Ledger Operations</h2>
        <p className="text-slate-500 dark:text-slate-400 text-sm">Log arrivals, process departures, calculate fees, and search archives.</p>
      </div>

      {/* Operations Panel (Admins Only) */}
      {user?.role === 'admin' ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Box 1: Arriving Check-In */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/80 rounded-3xl p-6 shadow-sm">
            <div className="flex items-center gap-2 mb-5">
              <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                <LogIn className="h-5 w-5" />
              </div>
              <h3 className="text-md font-bold text-slate-900 dark:text-white">Active Dispatch: Check-In Arrival</h3>
            </div>

            <form onSubmit={executeEntry} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 font-mono">SELECT VACANT SLOT</label>
                  <select
                    required
                    value={entrySlotId}
                    onChange={(e) => setEntrySlotId(e.target.value)}
                    className="w-full px-4 py-3 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold bg-white dark:bg-slate-950 text-slate-800 dark:text-white"
                  >
                    <option value="">-- vacant slots --</option>
                    {vacantSlots.map(s => (
                      <option key={s._id} value={s.slotId}>{s.slotId}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 font-mono">LICENSE PLATE NUMBER</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. CA-4122"
                    value={entryPlate}
                    onChange={(e) => setEntryPlate(e.target.value)}
                    className="w-full px-4 py-3 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold bg-white dark:bg-slate-950 uppercase focus:ring-2 focus:ring-emerald-500 outline-none text-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 font-mono">DRIVER / OWNER COMPEL FULL NAME</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Clark Kent"
                  value={entryOwner}
                  onChange={(e) => setEntryOwner(e.target.value)}
                  className="w-full px-4 py-3 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold bg-white dark:bg-slate-950 focus:ring-2 focus:ring-emerald-500 outline-none text-slate-800 dark:text-white"
                />
              </div>

              <button
                type="submit"
                disabled={vacantSlots.length === 0}
                className="w-full py-3 px-4 bg-emerald-500 hover:bg-emerald-600 disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed text-white rounded-xl text-sm font-bold transition-all"
              >
                {vacantSlots.length === 0 ? 'Parking Lot fully Occupied' : 'Confirm Entry & Log Arrival'}
              </button>
            </form>
          </div>

          {/* Box 2: Departures & Fee Calculations */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/80 rounded-3xl p-6 shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-5">
                <div className="p-2 rounded-xl bg-rose-500/10 text-rose-600 dark:text-rose-400">
                  <LogOut className="h-5 w-5" />
                </div>
                <h3 className="text-md font-bold text-slate-900 dark:text-white">Departures & Cashier Billing</h3>
              </div>

              <form onSubmit={executeExit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 font-mono">ENTER LOGGED PLATE NUMBER</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      required
                      placeholder="e.g. CA-9988"
                      value={exitPlate}
                      onChange={(e) => setExitPlate(e.target.value)}
                      className="flex-1 px-4 py-3 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold bg-white dark:bg-slate-950 uppercase focus:ring-2 focus:ring-rose-500 outline-none text-slate-800 dark:text-white"
                    />
                    <button
                      type="submit"
                      className="px-5 bg-rose-500 hover:bg-rose-600 text-white rounded-xl text-sm font-bold transition-all"
                    >
                      Check-Out
                    </button>
                  </div>
                </div>
              </form>

              {/* Fee bill result visual */}
              {activeExitDetail && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="mt-5 p-4 border border-rose-100 dark:border-rose-950/20 bg-rose-500/[0.02] rounded-2xl space-y-3.5 text-xs text-slate-700 dark:text-slate-300"
                >
                  <div className="flex items-center justify-between text-rose-600 dark:text-rose-400 font-extrabold font-mono uppercase text-[10px] tracking-wide">
                    <span>BILL RECEIPT GENERATED</span>
                    <button onClick={() => setActiveExitDetail(null)} className="hover:text-slate-800">✕</button>
                  </div>

                  <div className="grid grid-cols-2 gap-y-2 text-sm">
                    <div className="font-mono text-xs text-slate-400">Vehicle:</div>
                    <div className="text-right font-black text-slate-800 dark:text-white">{activeExitDetail.vehicleNumber}</div>

                    <div className="font-mono text-xs text-slate-400">Total Duration:</div>
                    <div className="text-right font-semibold text-slate-800 dark:text-white">{activeExitDetail.durationHours} hour(s)</div>

                    <div className="font-mono text-xs text-slate-400">Hourly Levy rate:</div>
                    <div className="text-right font-medium text-slate-800 dark:text-slate-300">$5.00/hr</div>
                  </div>

                  <div className="border-t border-slate-200 dark:border-slate-800/80 pt-2.5 flex items-center justify-between font-mono">
                    <span className="font-bold text-slate-500">TOTAL LEVY DUE:</span>
                    <span className="text-lg font-black text-rose-600 dark:text-rose-400">$ {activeExitDetail.fee}.00</span>
                  </div>
                </motion.div>
              )}
            </div>
            
            {!activeExitDetail && (
              <div className="text-xs text-slate-400 dark:text-slate-500 flex items-center gap-1.5 font-medium border-t border-slate-100 dark:border-slate-850/30 pt-3.5 italic mt-4 leading-relaxed">
                <Tag className="h-4 w-4 text-slate-300 shrink-0" />
                <span>Standard parking fees are calculated at checking departure. Fractional hours are rounded to next complete hour.</span>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="p-5 bg-amber-500/5 border border-amber-500/10 text-amber-800 dark:text-amber-400 rounded-2xl text-xs space-y-1.5 leading-relaxed">
          <h4 className="font-bold">Staff Console Access Profile</h4>
          <p>Manual Check-In dispatchers and Exit levying cashier controls are exclusive to Super Admins. Standard accounts can browse active/historical parking databases in the searchable archive ledger below.</p>
        </div>
      )}

      {/* Historical logs Search Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/80 rounded-3xl p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-2">
            <History className="h-5 w-5 text-blue-500" />
            <h3 className="text-md font-bold text-slate-900 dark:text-white">Parking Ledger Archives</h3>
          </div>

          {/* Search bar input */}
          <div className="flex gap-2 max-w-md w-full md:w-auto">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search plate or driver..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={handleSearchKeyPress}
                className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-blue-500 outline-none text-slate-800 dark:text-white"
              />
            </div>
            <button
              onClick={loadHistory}
              className="px-4.5 py-2 bg-slate-800 hover:bg-slate-900 dark:bg-slate-100 dark:hover:bg-slate-50 text-white dark:text-slate-900 rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              Search
            </button>
          </div>
        </div>

        {/* Ledger search list table */}
        <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800/80">
          <table className="w-full text-left text-xs divide-y divide-slate-100 dark:divide-slate-800/80">
            <thead className="bg-slate-50 dark:bg-slate-950 text-slate-500 dark:text-slate-400 font-bold uppercase font-mono text-[10px] tracking-wide">
              <tr>
                <th className="p-4">Owner Name</th>
                <th className="p-4">License Plate</th>
                <th className="p-4 text-center">Status</th>
                <th className="p-4">Arrival Entry</th>
                <th className="p-4">Departure Exit</th>
                <th className="p-4 text-right">Fee ($)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium">
              {searchLoading ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400">
                    <div className="animate-spin h-5 w-5 border-2 border-blue-500 border-t-transparent rounded-full mx-auto mb-2"></div>
                    Executing query index...
                  </td>
                </tr>
              ) : historyLogs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400 dark:text-slate-600">
                    No matching records found inside parking ledger.
                  </td>
                </tr>
              ) : (
                historyLogs.map((log) => {
                  const active = log.status === 'parked';
                  return (
                    <tr key={log._id} className="hover:bg-slate-50/50 dark:hover:bg-slate-900/30">
                      <td className="p-4 font-semibold text-slate-900 dark:text-white">{log.ownerName}</td>
                      <td className="p-4 font-mono font-bold text-blue-600 dark:text-blue-400">{log.vehicleNumber}</td>
                      <td className="p-4 text-center">
                        <span className={`inline-block px-2 py-0.5 rounded-full text-[9px] font-bold font-mono tracking-wide uppercase ${
                          active 
                            ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400' 
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-650'
                        }`}>
                          {log.status === 'parked' ? 'Parked' : 'Exited'}
                        </span>
                      </td>
                      <td className="p-4 font-mono text-slate-500 dark:text-slate-400 text-[11px]">
                        {new Date(log.entryTime).toLocaleDateString()} {new Date(log.entryTime).toLocaleTimeString()}
                      </td>
                      <td className="p-4 font-mono text-slate-500 dark:text-slate-400 text-[11px]">
                        {log.exitTime ? (
                          `${new Date(log.exitTime).toLocaleDateString()} ${new Date(log.exitTime).toLocaleTimeString()}`
                        ) : (
                          <span className="italic text-rose-500">Occupying Slot</span>
                        )}
                      </td>
                      <td className="p-4 text-right font-mono font-bold text-slate-900 dark:text-white">
                        {log.fee ? `$ ${log.fee}` : '$ 0'}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
export default VehiclesManagement;
