/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useApp } from '../context/AppContext';
import { CalendarRange, Trash2, CalendarDays, Key, MapPin, UserCheck, Timer } from 'lucide-react';
import { motion } from 'motion/react';

export const ReservationsSection: React.FC = () => {
  const { reservations, user, cancelReservation } = useApp();

  const handleCancel = async (id: string) => {
    if (confirm('Are you sure you want to cancel this slot priority booking?')) {
      await cancelReservation(id);
    }
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">Slot Reservations</h2>
        <p className="text-slate-500 dark:text-slate-400 text-sm">Review, monitor, and manage active priority bookings and hold leases.</p>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/85 rounded-3xl p-6 shadow-sm">
        <div className="flex items-center gap-2.5 mb-6">
          <CalendarRange className="h-5 w-5 text-blue-500" />
          <h3 className="text-md font-bold text-slate-900 dark:text-white">
            {user?.role === 'admin' ? 'All Active Reservations' : 'My Active Bookings'}
          </h3>
        </div>

        {/* Reservations grid list */}
        {reservations.length === 0 ? (
          <div className="text-center py-16 text-slate-400 dark:text-slate-600 space-y-2">
            <CalendarDays className="h-11 w-11 mx-auto stroke-1.2" />
            <p className="text-sm font-semibold">No active hold bookings</p>
            <p className="text-xs max-w-sm mx-auto">Slots can be reserved for priority arrival from the main Parking slots map view.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {reservations.map((res) => {
              const active = res.status === 'active';
              return (
                <motion.div
                  key={res._id}
                  id={`res-card-${res._id}`}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    {/* Badge header */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1 bg-blue-500/10 text-blue-600 dark:text-blue-400 font-mono text-xs font-black px-3 py-1 rounded-lg border border-blue-500/10">
                        <MapPin className="h-3.5 w-3.5" />
                        <span>SLOT {res.slotId}</span>
                      </div>
                      <span className={`inline-block px-2.5 py-0.5 rounded-full text-[9px] font-bold font-mono uppercase tracking-wide ${
                        res.status === 'active' 
                          ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 animate-pulse'
                          : res.status === 'fulfilled'
                            ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                            : 'bg-slate-200 text-slate-500'
                      }`}>
                        {res.status}
                      </span>
                    </div>

                    {/* Metadata */}
                    <div className="space-y-2.5 text-xs">
                      <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400 font-medium">
                        <Timer className="h-4 w-4 text-slate-400" />
                        <span className="font-semibold text-slate-700 dark:text-slate-350">Scheduled Time:</span>
                        <span className="font-mono ml-auto">
                          {new Date(res.reservationDate).toLocaleString()}
                        </span>
                      </div>

                      {user?.role === 'admin' && (
                        <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400 font-medium">
                          <UserCheck className="h-4 w-4 text-slate-400" />
                          <span className="font-semibold text-slate-700 dark:text-slate-350">Client User:</span>
                          <span className="font-bold ml-auto text-blue-600 dark:text-blue-400">
                            {res.userName}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions line */}
                  {active && (
                    <div className="border-t border-slate-200 dark:border-slate-850/60 mt-4.5 pt-3.5 flex justify-end">
                      <button
                        id={`cancel-res-btn-${res._id}`}
                        onClick={() => handleCancel(res._id)}
                        className="text-xs font-bold text-rose-600 hover:text-rose-700 dark:text-rose-400 bg-rose-500/5 hover:bg-rose-500/10 border border-rose-500/10 px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        <span>Cancel Hold Booking</span>
                      </button>
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      <div className="p-5 bg-blue-500/5 border border-blue-500/10 rounded-2xl text-xs text-slate-500 dark:text-slate-400 leading-relaxed font-medium">
        Holds are secured for priority users. If vehicles arrive and park physically in an active reserved slot, the reservation status transitions automatically to fulfilled to secure precision statistics logs.
      </div>
    </div>
  );
};
export default ReservationsSection;
