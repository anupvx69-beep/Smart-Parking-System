/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  LayoutDashboard, 
  Grid3X3, 
  Car, 
  CalendarCheck, 
  FileSpreadsheet, 
  LogOut, 
  User as UserIcon,
  Moon, 
  Sun, 
  Tv, 
  Menu, 
  X,
  ParkingCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const Sidebar: React.FC = () => {
  const { user, currentView, setCurrentView, logout, theme, toggleTheme } = useApp();
  const [mobileOpen, setMobileOpen] = useState(false);

  const menuItems = [
    { id: 'dashboard', name: 'Dashboard', icon: LayoutDashboard },
    { id: 'slots', name: 'Parking slots', icon: Grid3X3 },
    { id: 'vehicles', name: 'Vehicles log', icon: Car },
    ...(user?.role === 'admin' 
      ? [] 
      : [{ id: 'reservations', name: 'My reservations', icon: CalendarCheck }]
    ),
    { id: 'reports', name: 'Reports & Export', icon: FileSpreadsheet }
  ];

  const handleNav = (viewId: any) => {
    setCurrentView(viewId);
    setMobileOpen(false);
  };

  const navContent = (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 border-r border-slate-200 dark:border-slate-800 transition-colors duration-300">
      {/* Brand Profile Logo */}
      <div className="p-6 flex items-center gap-3 border-b border-slate-200 dark:border-slate-800/80">
        <div className="bg-blue-600 text-white p-2.5 rounded-xl shadow-lg ring-4 ring-blue-600/10">
          <ParkingCircle className="h-6 w-6" id="brand-logo-icon" />
        </div>
        <div>
          <h1 className="text-lg font-bold tracking-tight text-slate-900 dark:text-white">SmartPark<span className="text-blue-500">AI</span></h1>
          <p className="text-xs font-medium text-blue-600 dark:text-blue-400 font-mono">INTELLIGENT IOT</p>
        </div>
      </div>

      {/* Navigation Buttons List */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {menuItems.map((item) => {
          const IconComponent = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              id={`nav-${item.id}`}
              onClick={() => handleNav(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 border ${
                isActive 
                  ? 'bg-blue-600/10 text-blue-600 dark:text-blue-400 border-blue-600/20' 
                  : 'text-slate-650 dark:text-slate-400 hover:bg-slate-200/50 dark:hover:bg-slate-800 border-transparent hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <IconComponent className={`h-5 w-5 ${isActive ? 'text-blue-600 dark:text-blue-400' : 'text-slate-500 dark:text-slate-400'}`} />
              <span>{item.name}</span>
              {isActive && (
                <motion.div 
                  layoutId="activeBar" 
                  className="ml-auto w-1.5 h-5 bg-blue-500 rounded-full" 
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer Profile User Segment */}
      <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-100/55 dark:bg-slate-950/20">
        {user && (
          <div className="flex items-center gap-3 p-2.5 bg-white dark:bg-slate-850/50 border border-slate-200 dark:border-slate-800 rounded-xl mb-3">
            <div className="bg-slate-100 dark:bg-slate-800 p-2 rounded-lg text-slate-750 dark:text-slate-350">
              <UserIcon className="h-5 w-5" />
            </div>
            <div className="min-w-0 flex-1">
              <h4 className="text-sm font-semibold truncate text-slate-800 dark:text-slate-200">{user.name}</h4>
              <p className="text-xs font-mono capitalize text-slate-500 dark:text-slate-500">{user.role}</p>
            </div>
          </div>
        )}

        <div className="flex items-center justify-between gap-1">
          {/* Theme Toggler */}
          <button
            id="theme-toggler-btn"
            onClick={toggleTheme}
            className="flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-semibold bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-800 hover:bg-slate-105 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
          >
            {theme === 'light' ? (
              <>
                <Moon className="h-4 w-4" />
                <span>Dark Mode</span>
              </>
            ) : (
              <>
                <Sun className="h-4 w-4 text-amber-500" />
                <span>Light Mode</span>
              </>
            )}
          </button>

          {/* Log Out Button */}
          <button
            id="logout-button-btn"
            onClick={logout}
            className="p-2.5 rounded-xl border border-rose-200 hover:border-rose-300 dark:border-rose-950 hover:bg-rose-50 dark:hover:bg-rose-955 text-rose-600 dark:text-rose-400 transition-colors cursor-pointer"
            title="Sign Out"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden lg:block w-64 h-screen shrink-0 sticky top-0">
        {navContent}
      </aside>

      {/* Mobile Top Header Bar */}
      <header className="lg:hidden w-full h-16 bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between px-6 z-40 relative">
        <div className="flex items-center gap-2">
          <ParkingCircle className="h-6 w-6 text-blue-500" />
          <span className="text-lg font-bold text-slate-900 dark:text-white">SmartPark<span className="text-blue-500">AI</span></span>
        </div>
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="p-2 text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-lg cursor-pointer"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </header>

      {/* Mobile Sidebar overlay */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, x: -300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -300 }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-50 lg:hidden w-72 h-screen"
          >
            {navContent}
            {/* Backdrop click closer */}
            <div 
              className="fixed inset-0 bg-black/40 -z-10 w-screen h-screen left-72" 
              onClick={() => setMobileOpen(false)}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
export default Sidebar;
