/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ParkingSlot, SlotStatus } from '../types';
import { 
  PlusCircle, 
  MapPin, 
  Info, 
  ShieldAlert, 
  Clock, 
  Sparkles, 
  Radio, 
  Sliders, 
  UserPlus, 
  Calendar,
  XCircle,
  Play
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const SlotGrid: React.FC = () => {
  const { slots, user, reserveSlot, vehicleEntry, vehicleExit, triggerIotUpdate } = useApp();
  const [selectedSlot, setSelectedSlot] = useState<ParkingSlot | null>(null);
  const [activeZone, setActiveZone] = useState<'ALL' | 'A' | 'B' | 'C'>('ALL');
  
  // Dialog Actions State
  const [showReserveModal, setShowReserveModal] = useState(false);
  const [showEntryModal, setShowEntryModal] = useState(false);
  const [showIotModal, setShowIotModal] = useState(false);

  // Form Inputs
  const [resDate, setResDate] = useState('');
  const [vNumber, setVNumber] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [iotStatus, setIotStatus] = useState<SlotStatus>('occupied');

  const filteredSlots = activeZone === 'ALL' 
    ? slots 
    : slots.filter(s => s.slotId.startsWith(activeZone));

  // Count helper
  const availableCount = slots.filter(s => s.status === 'available').length;
  const occupiedCount = slots.filter(s => s.status === 'occupied').length;
  const reservedCount = slots.filter(s => s.status === 'reserved').length;

  const handleSlotClick = (slot: ParkingSlot) => {
    setSelectedSlot(slot);
    // Preset fields
    setResDate(new Date(Date.now() + 60 * 60 * 1000).toISOString().slice(0, 16)); // Default 1 hour from now
    setVNumber('');
    setOwnerName('');
  };

  const submitReservation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSlot || !resDate) return;
    
    const success = await reserveSlot(selectedSlot.slotId, new Date(resDate).toISOString());
    if (success) {
      setShowReserveModal(false);
      setSelectedSlot(null);
    }
  };

  const submitEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSlot || !vNumber || !ownerName) return;
    
    const success = await vehicleEntry(selectedSlot.slotId, vNumber, ownerName);
    if (success) {
      setShowEntryModal(false);
      setSelectedSlot(null);
    }
  };

  const submitIotSimulation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSlot) return;

    const sensorVeh = iotStatus === 'occupied' ? (vNumber || `IOT-NUM-${selectedSlot.slotId}`) : '';
    const sensorOwn = iotStatus === 'occupied' ? (ownerName || 'IoT Signal Sender') : '';

    const success = await triggerIotUpdate(selectedSlot.slotId, iotStatus, sensorVeh, sensorOwn);
    if (success) {
      setShowIotModal(false);
      setSelectedSlot(null);
    }
  };

  // Helper calculating live parking hours
  const calculateParkedHours = (entryTime: string | null) => {
    if (!entryTime) return 'N/A';
    const start = new Date(entryTime);
    const now = new Date();
    const diffMs = now.getTime() - start.getTime();
    const mins = Math.max(1, Math.round(diffMs / 60000));
    const hours = Math.ceil(mins / 60);
    return `${hours} hour(s) (${mins} mins)`;
  };

  return (
    <div className="space-y-6">
      {/* Tab Header & Quick count badges */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">Parking Grid Map</h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm">Visual status map representation of parking layout</p>
        </div>

        {/* Legend stats */}
        <div className="flex flex-wrap items-center gap-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-2xl shadow-sm text-xs font-semibold">
          <div className="flex items-center gap-1.5 px-2.5 py-1 text-emerald-700 bg-emerald-50 dark:text-emerald-400 dark:bg-emerald-950/30 rounded-lg">
            <span className="h-2 w-2 rounded-full bg-emerald-500"></span>
            <span>Available ({availableCount})</span>
          </div>
          <div className="flex items-center gap-1.5 px-2.5 py-1 text-rose-700 bg-rose-50 dark:text-rose-400 dark:bg-rose-950/30 rounded-lg">
            <span className="h-2 w-2 rounded-full bg-rose-500"></span>
            <span>Occupied ({occupiedCount})</span>
          </div>
          <div className="flex items-center gap-1.5 px-2.5 py-1 text-amber-700 bg-amber-50 dark:text-amber-400 dark:bg-amber-950/30 rounded-lg">
            <span className="h-2 w-2 rounded-full bg-amber-500"></span>
            <span>Reserved ({reservedCount})</span>
          </div>
        </div>
      </div>

      {/* Zone Switchers */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-1.5">
        {(['ALL', 'A', 'B', 'C'] as const).map((zone) => (
          <button
            key={zone}
            onClick={() => { setActiveZone(zone); setSelectedSlot(null); }}
            className={`px-4.5 py-2 rounded-xl text-xs font-bold tracking-wide transition-all ${
              activeZone === zone 
                ? 'bg-slate-800 dark:bg-slate-100 text-white dark:text-slate-900 shadow-sm' 
                : 'text-slate-500 dark:text-slate-400 hover:bg-slate-200/50 dark:hover:bg-slate-900/50'
            }`}
          >
            ZONE {zone}
          </button>
        ))}

        <div className="ml-auto text-emerald-600 dark:text-emerald-400 bg-emerald-100/10 border border-emerald-500/20 px-3 py-1 rounded-xl text-[10px] font-mono font-bold flex items-center gap-1.5 animate-pulse">
          <Radio className="h-3 w-3" />
          <span>REAL-TIME MAP SYNC</span>
        </div>
      </div>

      {/* Main Grid & Details layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Span: 30 Slots Cards Grid Layout */}
        <div className="lg:col-span-2 bg-slate-100/55 dark:bg-slate-950/30 border border-slate-200 dark:border-slate-900 rounded-3xl p-6">
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-3.5">
            {filteredSlots.map((slot) => {
              const available = slot.status === 'available';
              const occupied = slot.status === 'occupied';
              const reserved = slot.status === 'reserved';
              const isSelected = selectedSlot?.slotId === slot.slotId;

              return (
                <motion.button
                  key={slot._id}
                  id={`slot-card-${slot.slotId}`}
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleSlotClick(slot)}
                  className={`aspect-square p-3.5 rounded-2xl border text-left flex flex-col justify-between transition-all relative overflow-hidden ${
                    isSelected 
                      ? 'ring-4 ring-blue-500/30 border-blue-500 z-10 scale-102 bg-white dark:bg-slate-900' 
                      : available
                        ? 'bg-emerald-50/80 border-emerald-200/80 hover:border-emerald-300 dark:bg-emerald-950/10 dark:border-emerald-950 hover:bg-emerald-100/40'
                        : occupied
                          ? 'bg-rose-50/80 border-rose-200/80 hover:border-rose-300 dark:bg-rose-950/10 dark:border-rose-950 hover:bg-rose-100/40'
                          : 'bg-amber-50/80 border-amber-200/80 hover:border-amber-300 dark:bg-amber-950/10 dark:border-amber-950 hover:bg-amber-100/40'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="text-lg font-extrabold tracking-tight font-mono text-slate-800 dark:text-slate-100">{slot.slotId}</span>
                    <span className={`h-2.5 w-2.5 rounded-full ${
                      available ? 'bg-emerald-500' : occupied ? 'bg-rose-500' : 'bg-amber-500'
                    }`} />
                  </div>

                  {/* Tiny text indicating reservation or car number */}
                  <div className="mt-4 truncate">
                    {occupied ? (
                      <span className="text-[10px] font-mono leading-none tracking-tight text-rose-600 dark:text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-md">{slot.vehicleNumber}</span>
                    ) : reserved ? (
                      <span className="text-[10px] font-mono leading-none tracking-tight text-amber-600 dark:text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md">RESERVED</span>
                    ) : (
                      <span className="text-[10px] font-mono leading-none text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md">VACANT</span>
                    )}
                  </div>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Right Span: Selected Slot Details Visual & Options */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/80 rounded-3xl p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <MapPin className="h-5 w-5 text-blue-500" />
              <h3 className="text-md font-bold text-slate-900 dark:text-white">Active Node Detail</h3>
            </div>

            {selectedSlot ? (
              <div className="space-y-6 animate-fade-in">
                {/* Visual Banner badge */}
                <div className={`p-4 rounded-2xl flex items-center justify-between ${
                  selectedSlot.status === 'available' 
                    ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400' 
                    : selectedSlot.status === 'occupied'
                      ? 'bg-rose-500/10 text-rose-700 dark:text-rose-400'
                      : 'bg-amber-500/10 text-amber-700 dark:text-amber-400'
                }`}>
                  <div className="font-mono text-2xl font-black">{selectedSlot.slotId}</div>
                  <div className="text-xs font-extrabold uppercase px-3 py-1 rounded-full bg-white dark:bg-slate-950 font-mono border dark:border-slate-800">
                    {selectedSlot.status}
                  </div>
                </div>

                {/* Properties fields log */}
                <div className="space-y-3.5 divide-y divide-slate-100 dark:divide-slate-800/60 text-sm">
                  {selectedSlot.status === 'occupied' && (
                    <>
                      <div className="flex justify-between py-2.5">
                        <span className="text-slate-400 dark:text-slate-500 font-medium">Vehicle License</span>
                        <span className="font-mono font-bold text-slate-800 dark:text-slate-100">{selectedSlot.vehicleNumber}</span>
                      </div>
                      <div className="flex justify-between py-2.5">
                        <span className="text-slate-400 dark:text-slate-500 font-medium">Owner / Operator</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-100">{selectedSlot.ownerName || 'Unknown Owner'}</span>
                      </div>
                      <div className="flex justify-between py-2.5">
                        <span className="text-slate-400 dark:text-slate-500 font-medium">Arr. Entry Time</span>
                        <span className="font-mono text-xs text-slate-800 dark:text-slate-200">
                          {selectedSlot.entryTime ? new Date(selectedSlot.entryTime).toLocaleTimeString() : 'N/A'}
                        </span>
                      </div>
                      <div className="flex justify-between py-2.5 animate-pulse">
                        <span className="text-slate-400 dark:text-slate-500 font-medium">Park Duration</span>
                        <span className="font-semibold text-rose-600 dark:text-rose-400">{calculateParkedHours(selectedSlot.entryTime)}</span>
                      </div>
                    </>
                  )}

                  {selectedSlot.status === 'reserved' && (
                    <div className="p-4 bg-amber-500/5 border border-amber-500/10 rounded-2xl text-xs space-y-2 text-amber-800 dark:text-amber-400">
                      <div className="font-semibold flex items-center gap-1.5">
                        <Clock className="h-4 w-4" />
                        <span>Reserved Priority Slot</span>
                      </div>
                      <p>This slot is reserved for prioritized onboarding. It will re-open for booking if the user fails to initiate entry inside specified booking limit.</p>
                    </div>
                  )}

                  {selectedSlot.status === 'available' && (
                    <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl text-xs space-y-2 text-emerald-800 dark:text-emerald-400">
                      <div className="font-semibold flex items-center gap-1.5">
                        <Sparkles className="h-4 w-4" />
                        <span>Node Fully Available</span>
                      </div>
                      <p>Currently vacant and ready to accept immediate reservations or direct physical manual parking onboarding.</p>
                    </div>
                  )}

                  <div className="flex justify-between py-2.5 text-xs text-slate-400 dark:text-slate-500">
                    <span>Last Sensor Heartbeat</span>
                    <span className="font-mono">{new Date(selectedSlot.lastSensorUpdate).toLocaleTimeString()}</span>
                  </div>
                </div>

                {/* Operations grid actions panel */}
                <div className="space-y-2 pt-2">
                  {selectedSlot.status === 'available' && (
                    <>
                      {/* Reserve command */}
                      <button
                        id="action-reserve-btn"
                        onClick={() => setShowReserveModal(true)}
                        className="w-full py-3 hover:-translate-y-0.5 px-4 bg-slate-800 hover:bg-slate-900 border dark:border-slate-800 dark:bg-slate-100 dark:hover:bg-slate-50 text-white dark:text-slate-900 text-sm font-bold rounded-2xl transition-all shadow-sm"
                      >
                        Reserve Slot Priority
                      </button>

                      {/* Manual Entry (Admin panel exclusive) */}
                      {user?.role === 'admin' && (
                        <button
                          id="action-manual-entry-btn"
                          onClick={() => setShowEntryModal(true)}
                          className="w-full py-3 hover:-translate-y-0.5 px-4 bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-bold rounded-2xl transition-all shadow-sm"
                        >
                          Manual Onboard Entry
                        </button>
                      )}
                    </>
                  )}

                  {selectedSlot.status === 'occupied' && user?.role === 'admin' && (
                    <button
                      id="action-processed-exit-btn"
                      onClick={async () => {
                        await vehicleExit(selectedSlot.vehicleNumber);
                        setSelectedSlot(null);
                      }}
                      className="w-full py-3 hover:-translate-y-0.5 px-4 bg-rose-500 hover:bg-rose-600 text-white text-sm font-bold rounded-2xl transition-all shadow-sm"
                    >
                      Process Vehicle Exit
                    </button>
                  )}

                  {/* IoT trigger is ALWAYS accessible to let developers/users play with IoT endpoints! */}
                  <button
                    id="action-iot-simulation-btn"
                    onClick={() => setShowIotModal(true)}
                    className="w-full py-2 px-4 bg-slate-100 hover:bg-slate-200 dark:bg-slate-950/60 dark:hover:bg-slate-950 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <Sliders className="h-3.5 w-3.5" />
                    <span>Run IoT Sensor Simulation</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-16 text-center text-slate-400 dark:text-slate-600 space-y-3">
                <Info className="h-10 w-10 stroke-1.5" />
                <div>
                  <p className="text-sm font-semibold">No node selected</p>
                  <p className="text-xs max-w-[200px] mt-1 mx-auto leading-relaxed">Select any grid card on the left to review occupancy or start actions</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ==========================================
          MODALS DIALOG SYSTEMS (Animate-In)
          ========================================== */}
      
      {/* 1. RESERVATION FORM MODAL */}
      <AnimatePresence>
        {showReserveModal && selectedSlot && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/50 backdrop-blur-xs" 
              onClick={() => setShowReserveModal(false)} 
            />
            
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xl w-full max-w-md relative z-10"
            >
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-blue-500" />
                  <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">Reserve Slot {selectedSlot.slotId}</h3>
                </div>
                <button onClick={() => setShowReserveModal(false)} className="text-slate-400 dark:text-slate-500 hover:text-slate-700">✕</button>
              </div>

              <form onSubmit={submitReservation} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2 font-mono">RESERVATION DATE & TIME</label>
                  <input
                    type="datetime-local"
                    required
                    value={resDate}
                    onChange={(e) => setResDate(e.target.value)}
                    className="w-full px-4 py-3 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold bg-white dark:bg-slate-950 focus:ring-2 focus:ring-blue-500 outline-none text-slate-800 dark:text-white"
                  />
                </div>

                <div className="p-3 bg-blue-50 dark:bg-blue-950/20 text-xs text-blue-700 dark:text-blue-400 rounded-xl leading-relaxed">
                  Priority bookings are secured for up to 30 minutes from reservation target hour. Regular hourly parking rate schedules apply.
                </div>

                <div className="flex items-center gap-3 pt-3">
                  <button
                    type="button"
                    onClick={() => setShowReserveModal(false)}
                    className="flex-1 py-3 px-4 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 rounded-xl text-sm font-bold text-slate-700 dark:text-slate-300"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold cursor-pointer"
                  >
                    Confirm Booking
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 2. MANUAL VEHICLE ENTRY MODAL */}
      <AnimatePresence>
        {showEntryModal && selectedSlot && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/50 backdrop-blur-xs" 
              onClick={() => setShowEntryModal(false)} 
            />
            
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xl w-full max-w-md relative z-10"
            >
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-2">
                  <UserPlus className="h-5 w-5 text-emerald-500" />
                  <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">Manual Vehicle Entry ({selectedSlot.slotId})</h3>
                </div>
                <button onClick={() => setShowEntryModal(false)} className="text-slate-400 dark:text-slate-500 hover:text-slate-700">✕</button>
              </div>

              <form onSubmit={submitEntry} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 font-mono">VEHICLE LICENSE PLATE</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. CA-4400-X"
                    value={vNumber}
                    onChange={(e) => setVNumber(e.target.value)}
                    className="w-full px-4 py-3 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold bg-white dark:bg-slate-950 uppercase focus:ring-2 focus:ring-emerald-500 outline-none text-slate-800 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 font-mono">OPERATOR / OWNER NAME</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Martha Wayne"
                    value={ownerName}
                    onChange={(e) => setOwnerName(e.target.value)}
                    className="w-full px-4 py-3 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold bg-white dark:bg-slate-950 focus:ring-2 focus:ring-emerald-500 outline-none text-slate-800 dark:text-white"
                  />
                </div>

                <div className="flex items-center gap-3 pt-3">
                  <button
                    type="button"
                    onClick={() => setShowEntryModal(false)}
                    className="flex-1 py-3 px-4 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 rounded-xl text-sm font-bold text-slate-700 dark:text-slate-300"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3 px-4 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-sm font-bold"
                  >
                    Log Active Parking
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 3. IoT ENDPOINT SIMULATOR PANEL */}
      <AnimatePresence>
        {showIotModal && selectedSlot && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/60 backdrop-blur-xs" 
              onClick={() => setShowIotModal(false)} 
            />
            
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-white dark:bg-slate-900 border border-blue-500 dark:border-slate-800 rounded-3xl p-6 shadow-xl w-full max-w-md relative z-10"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Radio className="h-5 w-5 text-blue-500 animate-pulse" />
                  <h3 className="text-md font-extrabold text-slate-900 dark:text-white">IoT Node Telemetry</h3>
                </div>
                <button onClick={() => setShowIotModal(false)} className="text-slate-400 dark:text-slate-500 hover:text-slate-600">✕</button>
              </div>

              <div className="bg-slate-100 dark:bg-slate-955 border border-slate-100 dark:border-slate-800 p-3 rounded-2xl mb-4 text-xs space-y-1.5 text-slate-500 dark:text-slate-400 font-mono">
                <div className="text-blue-600 dark:text-blue-400 font-bold">API POST NETWORK WIRE:</div>
                <div className="overflow-x-auto select-all">
                  POST /api/slot/update
                </div>
                <div>
                  Header: Content-Type: application/json
                </div>
              </div>

              <form onSubmit={submitIotSimulation} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 font-mono">IOT TELEMETRY STATE</label>
                  <select
                    value={iotStatus}
                    onChange={(e: any) => setIotStatus(e.target.value)}
                    className="w-full px-4 py-3 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold bg-white dark:bg-slate-950 text-slate-800 dark:text-white"
                  >
                    <option value="occupied">Occupied (Car Arrived / Detector Triggered)</option>
                    <option value="available">Available (Car Left / Clean Loop Completed)</option>
                    <option value="reserved">Reserved (Remote Lock Block)</option>
                  </select>
                </div>

                {iotStatus === 'occupied' && (
                  <>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 font-mono">SIMULATED LICENSE NUMBER</label>
                      <input
                        type="text"
                        placeholder="IOT-PLATE-X"
                        value={vNumber}
                        onChange={(e) => setVNumber(e.target.value)}
                        className="w-full px-4 py-3 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold bg-white dark:bg-slate-950 uppercase text-slate-800 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 font-mono">SIMULATED OWNER INFO</label>
                      <input
                        type="text"
                        placeholder="IoT Simulated Driver"
                        value={ownerName}
                        onChange={(e) => setOwnerName(e.target.value)}
                        className="w-full px-4 py-3 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold bg-white dark:bg-slate-950 text-slate-800 dark:text-white"
                      />
                    </div>
                  </>
                )}

                <div className="flex items-center gap-3 pt-3">
                  <button
                    type="button"
                    onClick={() => setShowIotModal(false)}
                    className="flex-1 py-3 px-4 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-950 rounded-xl text-sm font-bold text-slate-600 dark:text-slate-400"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Play className="h-4 w-4" />
                    <span>Fire IoT Signal</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
export default SlotGrid;
