/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { LogIn, KeyRound, Sparkles, UserPlus, Fingerprint, ParkingCircle } from 'lucide-react';
import { motion } from 'motion/react';

export const AuthPage: React.FC = () => {
  const { login, register, errorMsg, successMsg } = useApp();
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);

  // Form Fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  // Prefill helper for frictionless demo trials
  const prefillAccount = (type: 'admin' | 'user') => {
    if (type === 'admin') {
      setEmail('admin@parking.com');
      setPassword('admin123');
    } else {
      setEmail('user@parking.com');
      setPassword('user123');
    }
    setIsLogin(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    if (isLogin) {
      await login(email, password);
    } else {
      await register(name, email, password);
    }
    
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-6 transition-colors duration-300">
      
      {/* Container */}
      <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850/80 rounded-3xl overflow-hidden shadow-xl shadow-slate-200/50 dark:shadow-black/25 flex flex-col p-8 space-y-6">
        
        {/* Brand identity header */}
        <div className="flex flex-col items-center text-center space-y-3">
          <div className="bg-emerald-500 text-white p-3.5 rounded-2xl shadow-lg ring-4 ring-emerald-500/10 mb-1">
            <ParkingCircle className="h-7 w-7" />
          </div>
          <div>
            <h1 className="text-2xl font-black tracking-tight text-slate-900 dark:text-white">SmartPark IoT</h1>
            <p className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 font-mono mt-0.5">PARKING DECISION PLATFORM</p>
          </div>
        </div>

        {/* Dynamic Errors logs feedback */}
        {errorMsg && (
          <div className="p-3.5 bg-rose-500/10 border border-rose-500/20 text-rose-600 dark:text-rose-400 text-xs font-semibold rounded-xl text-center animate-shake">
            {errorMsg}
          </div>
        )}

        {successMsg && (
          <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-semibold rounded-xl text-center">
            {successMsg}
          </div>
        )}

        {/* Demo Fast Preset buttons */}
        <div className="bg-slate-50 dark:bg-slate-950 p-4 border border-slate-100 dark:border-slate-850 rounded-2xl space-y-2.5">
          <div className="text-[10px] font-black text-slate-400 dark:text-slate-550 font-mono tracking-wider text-center uppercase flex items-center justify-center gap-1.5">
            <Sparkles className="h-3 w-3 text-emerald-500" />
            <span>FAST DEMO BYPASS PRESETS</span>
          </div>
          <div className="flex gap-2.5">
            <button
              id="demo-admin-login-btn"
              onClick={() => prefillAccount('admin')}
              className="flex-1 py-1.5 px-3 hover:-translate-y-0.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-extrabold rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 transition-all cursor-pointer text-center"
            >
              Super Admin
            </button>
            <button
              id="demo-user-login-btn"
              onClick={() => prefillAccount('user')}
              className="flex-1 py-1.5 px-3 hover:-translate-y-0.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-extrabold rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 transition-all cursor-pointer text-center"
            >
              Regular User
            </button>
          </div>
        </div>

        {/* Main interactive Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <div>
              <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 tracking-wide font-mono mb-1.5 text-left">FULL NAME</label>
              <input
                type="text"
                required
                placeholder="e.g. Rachel Al Ghul"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold bg-white dark:bg-slate-950 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          )}

          <div>
            <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 tracking-wide font-mono mb-1.5 text-left">EMAIL ROUTER ID</label>
            <input
              type="email"
              required
              placeholder="e.g. user@parking.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold bg-white dark:bg-slate-950 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 tracking-wide font-mono mb-1.5 text-left">SECURITY PASSCODE</label>
            <input
              type="password"
              required
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 border border-slate-200 dark:border-slate-800 rounded-xl text-sm font-semibold bg-white dark:bg-slate-950 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 px-4 bg-emerald-500 hover:bg-emerald-600 disabled:bg-slate-350 text-white rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer"
          >
            {isLogin ? (
              <>
                <LogIn className="h-4.5 w-4.5" />
                <span>{loading ? 'Authenticating...' : 'Sign In'}</span>
              </>
            ) : (
              <>
                <UserPlus className="h-4.5 w-4.5" />
                <span>{loading ? 'Creating Credentials...' : 'Register Account'}</span>
              </>
            )}
          </button>
        </form>

        {/* Footer Toggle text switches */}
        <div className="text-center text-xs text-slate-400 font-medium">
          {isLogin ? (
            <p>
              New in parking loop?{' '}
              <button
                id="toggle-register-form-btn"
                onClick={() => { setIsLogin(false); }}
                className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline"
              >
                Create Account
              </button>
            </p>
          ) : (
            <p>
              Already registered?{' '}
              <button
                id="toggle-login-form-btn"
                onClick={() => { setIsLogin(true); }}
                className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline"
              >
                Sign In Instead
              </button>
            </p>
          )}
        </div>

      </div>
    </div>
  );
};
export default AuthPage;
