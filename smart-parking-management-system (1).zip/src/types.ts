/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  _id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  password?: string;
}

export type SlotStatus = 'available' | 'occupied' | 'reserved';

export interface ParkingSlot {
  _id: string;
  slotId: string;
  status: SlotStatus;
  vehicleNumber: string;
  ownerName: string;
  entryTime: string | null;
  lastSensorUpdate: string;
}

export interface Reservation {
  _id: string;
  userId: string;
  userName: string;
  slotId: string;
  reservationDate: string;
  status: 'active' | 'cancelled' | 'fulfilled';
}

export interface Vehicle {
  _id: string;
  vehicleNumber: string;
  ownerName: string;
  entryTime: string;
  exitTime?: string;
  duration?: number; // in minutes
  fee?: number;
  status: 'parked' | 'exited';
}

export interface SystemNotification {
  id: string;
  type: 'info' | 'success' | 'warning' | 'danger';
  message: string;
  timestamp: string;
  read: boolean;
}

export interface DashboardStats {
  totalSlots: number;
  availableSlots: number;
  occupiedSlots: number;
  reservedSlots: number;
  todayRevenue: number;
  totalVehiclesParked: number;
}
