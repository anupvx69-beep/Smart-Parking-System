/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { io, Socket } from 'socket.io-client';
import { User, ParkingSlot, Reservation, Vehicle, SystemNotification, DashboardStats } from '../types';

interface AppContextType {
  user: User | null;
  token: string | null;
  slots: ParkingSlot[];
  reservations: Reservation[];
  notifications: SystemNotification[];
  currentView: 'dashboard' | 'slots' | 'vehicles' | 'reservations' | 'reports';
  theme: 'light' | 'dark';
  isLoading: boolean;
  stats: DashboardStats;
  analyticsData: any;
  errorMsg: string | null;
  successMsg: string | null;
  
  // Actions
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  setCurrentView: (view: any) => void;
  toggleTheme: () => void;
  
  // Parking & Vehicles
  reserveSlot: (slotId: string, reservationDate: string) => Promise<boolean>;
  cancelReservation: (resId: string) => Promise<boolean>;
  vehicleEntry: (slotId: string, vehicleNumber: string, ownerName: string) => Promise<boolean>;
  vehicleExit: (vehicleNumber: string) => Promise<any>;
  triggerIotUpdate: (slotId: string, status: string, vehicleNumber?: string, ownerName?: string) => Promise<boolean>;
  
  // Utilities
  addNotification: (message: string, type: 'info' | 'success' | 'warning' | 'danger') => void;
  clearNotification: (id: string) => void;
  refreshStatsAndAnalytics: () => Promise<void>;
  searchHistory: (term: string) => Promise<Vehicle[]>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('parking_token'));
  const [slots, setSlots] = useState<ParkingSlot[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [notifications, setNotifications] = useState<SystemNotification[]>([]);
  const [currentView, setCurrentView] = useState<'dashboard' | 'slots' | 'vehicles' | 'reservations' | 'reports'>('dashboard');
  const [theme, setTheme] = useState<'light' | 'dark'>((localStorage.getItem('parking_theme') as 'light' | 'dark') || 'dark');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [socket, setSocket] = useState<Socket | null>(null);

  const [stats, setStats] = useState<DashboardStats>({
    totalSlots: 30,
    availableSlots: 30,
    occupiedSlots: 0,
    reservedSlots: 0,
    todayRevenue: 0,
    totalVehiclesParked: 0
  });

  const [analyticsData, setAnalyticsData] = useState<any>({
    dailyOccupancy: [],
    weeklyOccupancy: [],
    monthlyRevenue: [],
    peakHours: []
  });

  // Theme Sync helper
  const toggleTheme = () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(nextTheme);
    localStorage.setItem('parking_theme', nextTheme);
  };

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  // Flash messages helper
  const triggerSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(null), 4000);
  };

  const triggerError = (msg: string) => {
    setErrorMsg(msg);
    setTimeout(() => setErrorMsg(null), 4000);
  };

  // Notification helpers
  const addNotification = (message: string, type: 'info' | 'success' | 'warning' | 'danger') => {
    const newNotif: SystemNotification = {
      id: 'notif_internal_' + Math.random().toString(36).substr(2, 9),
      message,
      type,
      timestamp: new Date().toISOString(),
      read: false
    };
    setNotifications(prev => [newNotif, ...prev].slice(0, 30)); // Limit to last 30 log items
  };

  const clearNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  // Parse token on launch & verify
  useEffect(() => {
    const fetchMe = async () => {
      if (!token) {
        setIsLoading(false);
        return;
      }
      try {
        const res = await fetch('/api/auth/me', {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          setUser(data.user);
        } else {
          // Token expired or invalid
          logout();
        }
      } catch (err) {
        console.error('Me verification failed', err);
      } finally {
        setIsLoading(false);
      }
    };
    fetchMe();
  }, [token]);

  // Synchronize dashboard stats & charts
  const refreshStatsAndAnalytics = async () => {
    try {
      const authHeader = token ? { Authorization: `Bearer ${token}` } : {};
      
      const [statsRes, analyticsRes] = await Promise.all([
        fetch('/api/dashboard/stats'),
        fetch('/api/dashboard/analytics')
      ]);

      if (statsRes.ok) {
        const statsData = await statsRes.json();
        setStats(statsData);
      }

      if (analyticsRes.ok) {
        const analyticsData = await analyticsRes.json();
        setAnalyticsData(analyticsData);
      }
    } catch (err) {
      console.error('Failed to sync chart stats', err);
    }
  };

  // Sync Reservations
  const refreshReservations = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/reservations', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setReservations(data);
      }
    } catch (err) {
      console.error('Reservations refresh failed', err);
    }
  };

  // Socket communication configuration
  useEffect(() => {
    const socketInstance = io(window.location.origin, {
      path: '/socket.io'
    });

    socketInstance.on('connect', () => {
      console.log('Real-time connection established');
    });

    socketInstance.on('parking:sync', (data: { slots: ParkingSlot[] }) => {
      setSlots(data.slots);
    });

    socketInstance.on('parking:update', (payload: { slots: ParkingSlot[], updatedSlot: ParkingSlot, notification: any }) => {
      setSlots(payload.slots);
      
      // Add socket notification
      if (payload.notification) {
        setNotifications(prev => [payload.notification, ...prev].slice(0, 30));
      }
      
      // Auto refresh stats and charts anytime a slot state shifts
      refreshStatsAndAnalytics();
      refreshReservations();
    });

    setSocket(socketInstance);

    return () => {
      socketInstance.disconnect();
    };
  }, [token]);

  // Refresh data initially
  useEffect(() => {
    refreshStatsAndAnalytics();
    refreshReservations();
  }, [user]);

  // AUTH ACTIONS
  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      setErrorMsg(null);
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });

      const data = await res.json();
      if (!res.ok) {
        triggerError(data.error || 'Authentication error');
        return false;
      }

      localStorage.setItem('parking_token', data.token);
      setToken(data.token);
      setUser(data.user);
      triggerSuccess(`Welcome back, ${data.user.name}!`);
      return true;
    } catch (err) {
      triggerError('Service unavailable. Please check backend connection.');
      return false;
    }
  };

  const register = async (name: string, email: string, password: string): Promise<boolean> => {
    try {
      setErrorMsg(null);
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password })
      });

      const data = await res.json();
      if (!res.ok) {
        triggerError(data.error || 'Registration error');
        return false;
      }

      localStorage.setItem('parking_token', data.token);
      setToken(data.token);
      setUser(data.user);
      triggerSuccess(`Account compiled successfully! Welcome ${data.user.name}.`);
      return true;
    } catch (err) {
      triggerError('Server communication failure. Please re-try register.');
      return false;
    }
  };

  const logout = () => {
    localStorage.removeItem('parking_token');
    setToken(null);
    setUser(null);
    setReservations([]);
    triggerSuccess('Session logged out successfully.');
  };

  // PARK VEHICLE ACTION
  const reserveSlot = async (slotId: string, reservationDate: string): Promise<boolean> => {
    try {
      const res = await fetch('/api/reservations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ slotId, reservationDate })
      });

      const data = await res.json();
      if (!res.ok) {
        triggerError(data.error || 'Reservation cancelled by safety handlers');
        return false;
      }

      triggerSuccess(`Slot ${slotId} is reserved successfully!`);
      refreshReservations();
      return true;
    } catch (err) {
      triggerError('Hardware timeout during slot reservation.');
      return false;
    }
  };

  // CANCEL RESERVATION
  const cancelReservation = async (resId: string): Promise<boolean> => {
    try {
      const res = await fetch(`/api/reservations/${resId}/cancel`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`
        }
      });

      const data = await res.json();
      if (!res.ok) {
        triggerError(data.error || 'Cancellation abort');
        return false;
      }

      triggerSuccess('Reservation cancelled successfully.');
      refreshReservations();
      return true;
    } catch (err) {
      triggerError('Error establishing cancel instruction.');
      return false;
    }
  };

  // VEHICLE ENTRY
  const vehicleEntry = async (slotId: string, vehicleNumber: string, ownerName: string): Promise<boolean> => {
    try {
      const res = await fetch('/api/vehicles/entry', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ slotId, vehicleNumber, ownerName })
      });

      const data = await res.json();
      if (!res.ok) {
        triggerError(data.error || 'Vehicle Entry rejected.');
        return false;
      }

      triggerSuccess(`Vehicle ${vehicleNumber.toUpperCase()} successfully logged into ${slotId}.`);
      return true;
    } catch (err) {
      triggerError('Entry node response timed out.');
      return false;
    }
  };

  // VEHICLE EXIT
  const vehicleExit = async (vehicleNumber: string): Promise<any> => {
    try {
      const res = await fetch('/api/vehicles/exit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ vehicleNumber })
      });

      const data = await res.json();
      if (!res.ok) {
        triggerError(data.error || 'Exit processing rejected.');
        return null;
      }

      triggerSuccess(`Exit completed. Duration: ${data.durationHours} hr(s). Processing fee: $${data.fee}.`);
      return data;
    } catch (err) {
      triggerError('Exit dispatcher offline.');
      return null;
    }
  };

  // IoT ENDPOINT SIMULATOR ACTION
  const triggerIotUpdate = async (slotId: string, status: string, vehicleNumber?: string, ownerName?: string): Promise<boolean> => {
    try {
      const res = await fetch('/api/slot/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ slotId, status, vehicleNumber, ownerName })
      });

      const data = await res.json();
      if (!res.ok) {
        triggerError(data.error || 'IoT broadcast rejected.');
        return false;
      }

      triggerSuccess(`IoT Update sent: Slot ${slotId} is now ${status}.`);
      return true;
    } catch (err) {
      triggerError('IoT Broker failed to dispatch message.');
      return false;
    }
  };

  // Search History logs
  const searchHistory = async (term: string): Promise<Vehicle[]> => {
    try {
      const res = await fetch(`/api/vehicles/history?search=${encodeURIComponent(term)}`);
      if (res.ok) {
        return await res.json();
      }
    } catch (err) {
      console.error('History query failed', err);
    }
    return [];
  };

  return (
    <AppContext.Provider
      value={{
        user,
        token,
        slots,
        reservations,
        notifications,
        currentView,
        theme,
        isLoading,
        stats,
        analyticsData,
        errorMsg,
        successMsg,
        login,
        register,
        logout,
        setCurrentView,
        toggleTheme,
        reserveSlot,
        cancelReservation,
        vehicleEntry,
        vehicleExit,
        triggerIotUpdate,
        addNotification,
        clearNotification,
        refreshStatsAndAnalytics,
        searchHistory
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used inside the AppProvider container');
  }
  return context;
};
