/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Sidebar } from './components/Sidebar';
import { DashboardOverview } from './components/DashboardOverview';
import { SlotGrid } from './components/SlotGrid';
import { VehiclesManagement } from './components/VehiclesManagement';
import { ReservationsSection } from './components/ReservationsSection';
import { ReportsSection } from './components/ReportsSection';
import { AuthPage } from './components/AuthPage';
import { NotificationsPanel } from './components/NotificationsPanel';
import { Chatbot } from './components/Chatbot';
import { ParkingCircle } from 'lucide-react';

const DashboardContent: React.FC = () => {
  const { currentView, isLoading } = useApp();

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <DashboardOverview />;
      case 'slots':
        return <SlotGrid />;
      case 'vehicles':
        return <VehiclesManagement />;
      case 'reservations':
        return <ReservationsSection />;
      case 'reports':
        return <ReportsSection />;
      default:
        return <DashboardOverview />;
    }
  };

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors duration-300">
      {/* Sidebar Navigation */}
      <Sidebar />

      {/* Main Workspace content panel Area */}
      <main className="flex-1 p-6 lg:p-10 overflow-y-auto max-w-7xl mx-auto w-full print:p-0 print:border-none">
        {renderView()}
      </main>

      {/* Slide-In Auto-Dismissing WebSocket Notifications */}
      <NotificationsPanel />

      {/* Floating Sparkly Chatbot Assistant Interface */}
      <Chatbot />
    </div>
  );
};

const RootApp: React.FC = () => {
  const { user, isLoading } = useApp();

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-950 text-slate-500 font-medium">
        <div className="relative flex h-14 w-14 items-center justify-center mb-4">
          {/* Pulsing ring animation */}
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400/25 opacity-75"></span>
          <div className="bg-emerald-500 text-white p-3 rounded-2xl shadow-xl">
            <ParkingCircle className="h-6 w-6 animate-spin" />
          </div>
        </div>
        <p className="text-sm font-semibold text-slate-700 dark:text-slate-350 tracking-wide font-mono animate-pulse">
          COMPILING SMARTPARK IoT CLOUD...
        </p>
      </div>
    );
  }

  return user ? <DashboardContent /> : <AuthPage />;
};

export default function App() {
  return (
    <AppProvider>
      <RootApp />
    </AppProvider>
  );
}
